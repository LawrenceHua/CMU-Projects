package ds.edu.project4lhuafinal;
//Lawrence Hua
//LHUA
import com.squareup.picasso.Picasso;

import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;
import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.URLEncoder;
import java.util.List;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {
    private EditText searchTermEditText;
    private Button submitButton;
    private TextView feedbackTextView;

    private OkHttpClient client = new OkHttpClient();
    MainActivity me = this;
    private ImageView imageView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Find views by ID
        searchTermEditText = findViewById(R.id.searchTerm);
        submitButton = findViewById(R.id.submit);
        feedbackTextView = findViewById(R.id.feedback);
        imageView = findViewById(R.id.imageView);

        // Set click listener for the submit button
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the user input from the EditText
                String userInput = searchTermEditText.getText().toString();
                if (isAlpha(userInput)) {
                    new FetchMealInfoTask().execute(userInput);
                } else {
                    feedbackTextView.setText("Please input letters only!");
                }
                // Execute AsyncTask to fetch meal information

            }
        });
    }
    public static boolean isAlpha(String input) {
        for (int i = 0; i < input.length(); i++) {
            char ch = input.charAt(i);
            if (!Character.isLetter(ch) && ch != ' ' && ch != '(' && ch != ')') {
                return false;
            }
        }
        return true;
    }
    private class FetchMealInfoTask extends AsyncTask<String, Void, Meal> {

        @Override
        protected Meal doInBackground(String... params) {
            String name = params[0];
            try {
                return fetchMealInfo(name);
            } catch (IOException | JSONException e) {
                e.printStackTrace();
                return null;
            }
        }

        @Override
        protected void onPostExecute(Meal mealInfo) {
            if (mealInfo != null) {
                // Display the fetched meal information
                StringBuilder mealDetails = new StringBuilder();

                mealDetails.append("Meal name: ").append(mealInfo.getStrMeal()).append("\n\n");
                // Append meal ID
                mealDetails.append("Meal ID: ").append(mealInfo.getIdMeal()).append("\n\n");

                mealDetails.append("Ingredients:\n");
                List<String> ingredients = mealInfo.getIngredients();
                List<String> measures = mealInfo.getMeasures();
                if (ingredients != null && measures != null && ingredients.size() == measures.size()) {
                    for (int i = 0; i < ingredients.size(); i++) {
                        String ingredient = ingredients.get(i);
                        String measure = measures.get(i);
                        // Check if both ingredient and measure are not null and not empty before appending
                        if (ingredient != null && !ingredient.isEmpty() && measure != null && !measure.isEmpty()) {
                            mealDetails.append(i + 1).append(") ").append(measure).append(" ").append(ingredient).append("\n");
                        }
                    }
                }


                // Append instructions
                mealDetails.append("\nInstructions:\n");
                mealDetails.append(mealInfo.getStrInstructions());
                Picasso.get().load(mealInfo.getStrMealThumb()).into(imageView);
                feedbackTextView.setText(mealDetails.toString());
            } else {
                Picasso.get().cancelRequest(imageView);
                imageView.setImageResource(android.R.color.transparent);
                feedbackTextView.setText("No recipes found");
            }
        }

    }

    private Meal fetchMealInfo(String name) throws IOException, JSONException {
        String deviceModel = Build.MODEL;
        String manufacturer = Build.MANUFACTURER;
        String osVersion = Build.VERSION.RELEASE;

        String url = "https://friendly-space-chainsaw-vr9qw7r6gq3prgw-8080.app.github.dev/recipe-servlet?search=" +
                URLEncoder.encode(name, "UTF-8") +
                "&deviceModel=" + URLEncoder.encode(deviceModel, "UTF-8") +
                "&manufacturer=" + URLEncoder.encode(manufacturer, "UTF-8") +
                "&osVersion=" + URLEncoder.encode(osVersion, "UTF-8");

        Request request = new Request.Builder().url(url).build();

        try (Response response = client.newCall(request).execute()) {
            if (!response.isSuccessful()) throw new IOException("Unexpected code " + response);
            String jsonResponse = response.body().string();
            return parseMealInfo(jsonResponse);
        }
    }

    private Meal parseMealInfo(String jsonResponse) throws JSONException {
        JSONObject jsonObject = new JSONObject(jsonResponse);
        Meal meal = new Meal();
        JSONArray mealsArray = null;
        // Extracting the meals array from the JSON object
        if (jsonObject.has("meals")) {
            // Get the JSONArray for the "meals" key
             mealsArray = jsonObject.getJSONArray("meals");

        // Checking if the meals array is not empty
        if (mealsArray.length() > 0) {
            // Getting the first meal object from the array
            JSONObject firstMeal = mealsArray.getJSONObject(0);

            // Extracting the idMeal from the first meal object
            String idMeal = firstMeal.optString("idMeal");

            // Extracting other meal details
            String strMeal = firstMeal.optString("strMeal");
            String strCategory = firstMeal.optString("strCategory");
            String strArea = firstMeal.optString("strArea");
            String strInstructions = firstMeal.optString("strInstructions");
            String strMealThumb = firstMeal.optString("strMealThumb");
            String strYoutube = firstMeal.optString("strYoutube");

            System.out.println(strMealThumb);
            // Extracting ingredients
            List<String> ingredients = new ArrayList<>();
            for (int i = 1; i <= 20; i++) {
                String ingredient = firstMeal.optString("strIngredient" + i);
                if (!ingredient.isEmpty()&&!ingredient.equals("null")) {
                    ingredients.add(ingredient);
                }
            }

            // Extracting measures
            List<String> measures = new ArrayList<>();
            for (int i = 1; i <= 20; i++) {
                String measure = firstMeal.optString("strMeasure" + i);
                if (!measure.isEmpty() && !measure.equals("null")) {
                    measures.add(measure);
                }
            }
            // Setting values to the Meal object
            meal.setIdMeal(idMeal);
            meal.setStrMeal(strMeal);
            meal.setStrCategory(strCategory);
            meal.setStrArea(strArea);
            meal.setStrInstructions(strInstructions);
            meal.setStrMealThumb(strMealThumb);
            meal.setStrYoutube(strYoutube);
            meal.setIngredients(ingredients);
            meal.setMeasures(measures);
        }
            return meal;
        } else {
            // Handle the case where there's no value for the "meals" key
            System.out.println("No meals found in the JSON object");
            return null;
        }

    }
}
