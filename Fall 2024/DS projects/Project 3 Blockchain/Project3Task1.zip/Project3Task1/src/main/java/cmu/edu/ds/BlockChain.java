package cmu.edu.ds;
//lawrence hua
//lhua
//lhua@andrew.cmu.edu
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Represents a blockchain consisting of blocks.
 */
public class BlockChain {
    ArrayList<Block> chain; // List to hold blocks in the blockchain
    private String chainHash; // Hash of the entire blockchain
    static int hashesPerSecond; // Number of hashes computed per second

    /**
     * Constructs an empty blockchain.
     */
    public BlockChain() {
        this.chain = new ArrayList<>();
        this.chainHash = "";
        this.hashesPerSecond = 0;
    }

    /**
     * Adds a new block to the blockchain.
     * @param newBlock The block to be added.
     */
    public void addBlock(Block newBlock){
        newBlock.setPreviousHash(this.chainHash);
        this.chain.add(newBlock);
        this.chainHash = newBlock.proofOfWork();
    }

    /**
     * Gets the size of the blockchain.
     * @return The number of blocks in the chain.
     */
    public int getChainSize() {
        return chain.size();
    }

    /**
     * Gets the number of hashes computed per second.
     * @return The number of hashes computed per second.
     */
    public int getHashesPerSecond() {
        return hashesPerSecond;
    }

    /**
     * Retrieves the latest block in the blockchain.
     * @return The latest block.
     */
    public Block getLatestBlock() {
        if (!chain.isEmpty()) {
            return chain.get(chain.size() - 1);
        } else {
            return null; // Return null if chain is empty
        }
    }

    /**
     * Gets the hash of the entire blockchain.
     * @return The hash of the blockchain.
     */
    public String getChainHash() {
        if (!chain.isEmpty()) {
            return chainHash;
        } else {
            return ""; // Return empty string if chain is empty
        }
    }

    /**
     * Gets the current system time.
     * @return The current system time.
     */
    public Timestamp getTime() {
        return new Timestamp(System.currentTimeMillis());
    }

    /**
     * Computes the total difficulty of the blockchain.
     * @return The total difficulty of all blocks in the chain.
     */
    public int getTotalDifficulty() {
        int totalDifficulty = 0;
        for (Block block : chain) {
            totalDifficulty += block.getDifficulty();
        }
        return totalDifficulty;
    }

    /**
     * Computes the total expected number of hashes required for the entire blockchain.
     * @return The total expected number of hashes.
     */
    public double getTotalExpectedHashes() {
        long totalExpectedHashes = 0;
        for (Block block : chain) {
            totalExpectedHashes += Math.pow(16, block.getDifficulty());
        }
        return totalExpectedHashes;
    }

    /**
     * Checks if the blockchain is valid.
     * @return "TRUE" if the chain is valid, otherwise an error message.
     */
    public String isChainValid() {
        // Check if the chain is empty
        if (chain.isEmpty()) {
            return "FALSE" + "\n" + "Empty Chain";
        }

        int i = 0;
        while (i < chain.size()) {
            Block block = chain.get(i);
            String computedHash = block.calculateHash();
            String existingHash;
            if (i == chain.size() - 1) {
                existingHash = chainHash; //if theres only 1 block, then assign the chainhash as the existinghash
            } else {
                // Else, use the next block's hash.
                existingHash = chain.get(i + 1).getPreviousHash();
            }

            // Check if chainhash = computedhash or if the difficulty does not match, then false
            int j = 0;
            while (j < block.getDifficulty()) {
                if (computedHash.charAt(j) != '0') {
                    return "FALSE" + "\n" + "Improper hash on node " + i + " Does not begin with " + "0".repeat(block.getDifficulty());
                }
                j++;
            }
            if (!computedHash.equals(existingHash)) {
                return "FALSE" + "\n" + "Improper hash on node " + i + " Does not begin with " + "0".repeat(block.getDifficulty());
            }
            i++;
        }

        // After all checks, return true
        return "TRUE";
    }

    /**
     * Repairs the blockchain by recalculating incorrect hashes.
     */
    public void repairChain() {
        int i = 0;
        while (i < chain.size()) {
            Block block = chain.get(i);
            String computedHash = block.calculateHash();
            String existingHash;

            if (i != chain.size()-1) {
                existingHash = chain.get(i + 1).getPreviousHash();
            } else {
                existingHash = chainHash; //if there's only 1 block, then assign the chainhash as the existinghash
            }
            while (!computedHash.startsWith("0".repeat(block.getDifficulty()))) {
                block.proofOfWork();
                computedHash = block.calculateHash();
            }
            // If existingHash doesn't equal computed hash
            if (!computedHash.equals(existingHash)) {
                //update the next block's hash if i isnt the same size of the chain.
                if (i != chain.size()-1){
                    chain.get(i + 1).setPreviousHash(computedHash);
                } else {
                    //assign the chainhash to computed hash if only 1 block
                    chainHash = computedHash;
                }
            }
            i++;
        }
    }

    /**
     * Computes the number of hashes per second.
     * @throws NoSuchAlgorithmException If the algorithm is not found.
     */
    public static void computeHashesPerSecond() throws NoSuchAlgorithmException {
        long startTime = System.currentTimeMillis();
        int numberOfHashes = 2000000;
        String str = "00000000";
        for (int i = 0; i < numberOfHashes; i++) {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(str.getBytes());
            md.digest();
        }
        long endTime = System.currentTimeMillis();
        double elapsedTime = ((endTime-startTime)/1000.0);

        hashesPerSecond = (int) (numberOfHashes / elapsedTime);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("{");
        sb.append("\"ds_chain\" : [ ");

        // Iterate through each block in the chain
        for (int i = 0; i < chain.size(); i++) {
            Block block = chain.get(i);
            sb.append("{");
            sb.append("\"index\" : ").append(i).append(",");
            sb.append("\"time stamp\" : \"").append(block.getTimestamp()).append("\",");
            sb.append("\"Tx \": \"").append(block.getData()).append("\",");
            sb.append("\"PrevHash\" : \"").append(block.getPreviousHash()).append("\",");
            sb.append("\"nonce\" : ").append(block.getNonce()).append(",");
            sb.append("\"difficulty\": ").append(block.getDifficulty()).append("");
            sb.append("}");
            // Append comma if not last block
            if (i < chain.size() - 1) {
                sb.append(",");
            }
            sb.append("\n");
        }

        sb.append("],");
        sb.append("\"chainHash\": \"").append(chainHash).append("\"");
        sb.append("}");

        return sb.toString();
    }
}
