package cmu.edu.ds;
//lawrence hua
//lhua
//lhua@andrew.cmu.edu
import com.google.gson.Gson;

public class RequestMessage {
    private String message;
    private int numberOfBlocks; // Number of blocks in the blockchain

    public RequestMessage(String message) {
        this.message = message;
        this.numberOfBlocks = numberOfBlocks;

    }

    public RequestMessage(String userInput, String difficultyInput, String transactionInput) {
        this.message = userInput + " " + difficultyInput + " " + transactionInput;
    }

    public String getMessage() {
        return message;
    }

    public String toJson() {
        Gson gson = new Gson();
        return gson.toJson(this);
    }

    public static RequestMessage fromJson(String json) {
        Gson gson = new Gson();
        return gson.fromJson(json, RequestMessage.class);
    }
}
