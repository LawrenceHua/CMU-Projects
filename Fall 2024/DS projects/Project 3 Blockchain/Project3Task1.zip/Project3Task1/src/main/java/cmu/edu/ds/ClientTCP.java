package cmu.edu.ds;
//lawrence hua
//lhua
//lhua@andrew.cmu.edu
import java.io.*;
import java.net.*;
import java.util.Scanner;

public class ClientTCP {
    public static void main(String args[]) {
        Socket clientSocket = null;
        Scanner scanner = new Scanner(System.in);

        try {
            int serverPort = 7777;
            clientSocket = new Socket("localhost", serverPort);

            BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            PrintWriter out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream())));

            String userInput;
            while (true) {
                // Display the menu
                displayMenu();

                // Get user input
                userInput = scanner.nextLine();

                // If user chooses to exit
                if (userInput.equals("6")) {
                    // Send exit signal to server
                    out.println(userInput);
                    out.flush();
                    break; // Exit the loop
                }
                // If user chose option 1, which requires more interaction
                if (userInput.equals("1")) {
                    // Request additional information from the user
                    System.out.println("Enter difficulty > 1: ");
                    String difficultyInput = scanner.nextLine();
                    System.out.println("Enter transaction: ");
                    String transactionInput = scanner.nextLine();
                    RequestMessage requestMessage = new RequestMessage(userInput, difficultyInput, transactionInput);
                    // Convert the request to JSON
                    String jsonRequest = requestMessage.toJson();

                    // Send the JSON request to the server
                    out.println(jsonRequest);
                    out.flush();
                }
                // If user chose option 4, which requires more interaction
                else if (userInput.equals("4")) {
                    System.out.println("Currupt the Blockchain");
                    System.out.println("Enter block ID of block to corrupt: ");
                    String blockID = scanner.nextLine();
                    System.out.println("Enter new data for block " + blockID + ": ");
                    String newData = scanner.nextLine();
                    RequestMessage requestMessage = new RequestMessage(userInput,blockID, newData);

                    // Convert the request to JSON
                    String jsonRequest = requestMessage.toJson();

                    // Send the JSON request to the server
                    out.println(jsonRequest);
                    out.flush();
                }
                // For other cases, send user input directly to server
                else {
                    RequestMessage requestMessage = new RequestMessage(userInput);
                    // Convert the request to JSON
                    String jsonRequest = requestMessage.toJson();

                    // Send the JSON request to the server
                    out.println(jsonRequest);
                    out.flush();
                }

                // Read response from server
                String jsonResponse = in.readLine();

                // Deserialize the JSON response into a response object
                ResponseMessage responseMessage = ResponseMessage.fromJSON(jsonResponse);

// Extract the content from the response message
                String content = responseMessage.getMessage();

// Print the content
                System.out.print(content);
            }
        } catch (IOException e) {
            System.out.println("IO Exception: " + e.getMessage());
        } finally {
            try {
                if (clientSocket != null) {
                    clientSocket.close();
                }
            } catch (IOException e) {
                // ignore exception on close
            }
        }
    }

    private static void displayMenu() {
        System.out.println("0. View basic blockchain status.");
        System.out.println("1. Add a transaction to the blockchain.");
        System.out.println("2. Verify the blockchain.");
        System.out.println("3. View the blockchain.");
        System.out.println("4. Corrupt the chain.");
        System.out.println("5. Hide the curruption by recomputing hashes.");
        System.out.println("6. Exit.");
        System.out.println("Enter your choice: ");
    }
}
