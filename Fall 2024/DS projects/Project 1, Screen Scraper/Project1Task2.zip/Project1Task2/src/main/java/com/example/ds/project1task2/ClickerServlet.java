package com.example.ds.project1task2;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "ClickerServlet", value = {"/initialWelcomeScreen", "/submit", "/getResults"})
public class ClickerServlet extends HttpServlet {
    private final ClickerModel model = new ClickerModel();

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Handle GET requests
        String path = request.getServletPath();

        if ("/getResults".equals(path)) {
            request.setAttribute("results", model.getResults());
            request.getRequestDispatcher("/view/resultsScreen.jsp").forward(request, response);
            model.clearResults(); // Clear results after displaying them
        } else {
            RequestDispatcher view = request.getRequestDispatcher("/view/welcomeScreen.jsp");
            view.forward(request, response);
        }
    }


    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Add to the answer param to post score in the next round
        String answer = request.getParameter("answer");

        if (answer != null && !answer.isEmpty()) {
            //everytime we submit an answer, we save to a map and eventually spit that out in getResults
            model.submitAnswer(answer);
            request.setAttribute("answer", answer);
            // Forward the request (answer) back to the welcome screen
            request.getRequestDispatcher("/view/welcomeScreen.jsp").forward(request, response);
        } else {
            // Handle invalid answer by redirecting back to the welcome screen
            response.sendRedirect(request.getContextPath() + "/view/resultsScreen.jsp");
        }
    }


}


