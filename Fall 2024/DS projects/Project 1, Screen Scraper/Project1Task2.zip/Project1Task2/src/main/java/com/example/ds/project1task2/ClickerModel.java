package com.example.ds.project1task2;

import java.util.HashMap;
import java.util.Map;
//Model for clicker
public class ClickerModel {
    private final Map<String, Integer> results = new HashMap<>();
//puts answers in the results map. If its the first time seeing the value itll add 1 to it.

    public void submitAnswer(String answer) {
        results.put(answer, results.getOrDefault(answer, 0) + 1);
    }
    public Map<String, Integer> getResults() {
        return results;
    }
    public void clearResults() {
        results.clear();
    }
}
