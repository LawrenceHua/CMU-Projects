package com.example.ds.project1task3;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.Map;

public class StateController extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String selectedState = request.getParameter("selectedState");
        Map<String, String> statePopulationMap = StateModel.getStatePopulation(selectedState);
        String URL = StateModel.getAPIURL(selectedState);
        System.out.println(URL);
        // Set the populated data as an attribute in the request
        request.setAttribute("statePopulationMap", statePopulationMap);
        request.setAttribute("URL", URL);
        // Forward the request to the JSP page for rendering
        RequestDispatcher dispatcher = request.getRequestDispatcher("/view/state.jsp");
        dispatcher.forward(request, response);
    }
}