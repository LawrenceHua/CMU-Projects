package com.example.ds.project1task3;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class StateModel {
    private static final String CENSUS_API_URL = "https://api.census.gov/data/2020/dec/pl?get=P1_001N";
    private static final String STATE_INFO_URL = "https://example.com/state-info/";


    public static Map<String, String> getStatePopulation(String selectedState) {
        Map<String, String> statePopulationMap = new HashMap<>();
        try {
            String apiUrl = getAPIURL(selectedState);
            String jsonData = fetchJsonData(apiUrl);
            JsonParser parser = new JsonParser();
            JsonArray dataArray = parser.parse(jsonData).getAsJsonArray();
            //puts data found into a map and returns that map to post
            for (int i = 1; i < dataArray.size(); i++) {
                JsonArray stateData = dataArray.get(i).getAsJsonArray();
                String stateName = getStateNameByFips(stateData.get(stateData.size() - 1).getAsString());
                String population = stateData.get(0).getAsString();
                statePopulationMap.put(stateName, population);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return statePopulationMap;
    }

    public static String getAPIURL(String selectedState){
        // Get the FIPS code for the selected state
        String fipsCode = getFipsCode(selectedState);
        if (fipsCode.isEmpty()) {
            return "FIPS NOT FOUND";
        }
        // Modify the API URL to include the FIPS code of the selected state
        String apiUrl = CENSUS_API_URL + "&for=state:" + fipsCode;
        return apiUrl;
    }


    private static String fetchJsonData(String url) throws IOException {
        return Jsoup.connect(url).ignoreContentType(true).execute().body();
    }

    private static final Map<String, String> STATE_FIPS_MAP = createStateFipsMap();

    private static Map<String, String> createStateFipsMap() {
        Map<String, String> stateFipsMap = new HashMap<>();
        stateFipsMap.put("Alabama", "01");
        stateFipsMap.put("Alaska", "02");
        stateFipsMap.put("Arizona", "04");
        stateFipsMap.put("Arkansas", "05");
        stateFipsMap.put("California", "06");
        stateFipsMap.put("Colorado", "08");
        stateFipsMap.put("Connecticut", "09");
        stateFipsMap.put("Delaware", "10");
        stateFipsMap.put("Florida", "12");
        stateFipsMap.put("Georgia", "13");
        stateFipsMap.put("Hawaii", "15");
        stateFipsMap.put("Idaho", "16");
        stateFipsMap.put("Illinois", "17");
        stateFipsMap.put("Indiana", "18");
        stateFipsMap.put("Iowa", "19");
        stateFipsMap.put("Kansas", "20");
        stateFipsMap.put("Kentucky", "21");
        stateFipsMap.put("Louisiana", "22");
        stateFipsMap.put("Maine", "23");
        stateFipsMap.put("Maryland", "24");
        stateFipsMap.put("Massachusetts", "25");
        stateFipsMap.put("Michigan", "26");
        stateFipsMap.put("Minnesota", "27");
        stateFipsMap.put("Mississippi", "28");
        stateFipsMap.put("Missouri", "29");
        stateFipsMap.put("Montana", "30");
        stateFipsMap.put("Nebraska", "31");
        stateFipsMap.put("Nevada", "32");
        stateFipsMap.put("New Hampshire", "33");
        stateFipsMap.put("New Jersey", "34");
        stateFipsMap.put("New Mexico", "35");
        stateFipsMap.put("New York", "36");
        stateFipsMap.put("North Carolina", "37");
        stateFipsMap.put("North Dakota", "38");
        stateFipsMap.put("Ohio", "39");
        stateFipsMap.put("Oklahoma", "40");
        stateFipsMap.put("Oregon", "41");
        stateFipsMap.put("Pennsylvania", "42");
        stateFipsMap.put("Rhode Island", "44");
        stateFipsMap.put("South Carolina", "45");
        stateFipsMap.put("South Dakota", "46");
        stateFipsMap.put("Tennessee", "47");
        stateFipsMap.put("Texas", "48");
        stateFipsMap.put("Utah", "49");
        stateFipsMap.put("Vermont", "50");
        stateFipsMap.put("Virginia", "51");
        stateFipsMap.put("Washington", "53");
        stateFipsMap.put("West Virginia", "54");
        stateFipsMap.put("Wisconsin", "55");
        stateFipsMap.put("Wyoming", "56");
        return stateFipsMap;
    }

    public static String getFipsCode(String stateName) {
        return STATE_FIPS_MAP.getOrDefault(stateName, "");
    }


    public static String getStateNameByFips(String fipsCode) {
        for (Map.Entry<String, String> entry : STATE_FIPS_MAP.entrySet()) {
            if (entry.getValue().equals(fipsCode)) {
                return entry.getKey();
            }
        }
        return "Unknown";
    }

}