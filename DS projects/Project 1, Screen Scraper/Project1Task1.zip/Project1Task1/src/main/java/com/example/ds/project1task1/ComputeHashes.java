package com.example.ds.project1task1;

import java.io.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import jakarta.xml.bind.DatatypeConverter;


@WebServlet(name = "ComputeHashes", value = "/compute-hashes")
public class ComputeHashes extends HttpServlet {
    private String message;

    public void init() {
        message = "Hello World!";
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html");

        // Hello
        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        out.println("<h1>" + message + "</h1>");
        out.println("</body></html>");
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html");

        //gets the returned value of the submission form. Whatever is checked will be returned.
        String inputText = request.getParameter("inputText");
        String algorithm = request.getParameter("algorithm");

        //print writer basically just allows us to send text back to the user
        PrintWriter out = response.getWriter();
        out.println("<html><body>");

        //creates "results" page after submission, else just asks user to enter text
        if (inputText != null && !inputText.isEmpty()) {
            out.println("<h2>Original Text: " + inputText + "</h2>");
            out.println("<h2>Hash Algorithm: " + algorithm + "</h2>");
            out.println("<h2>Hash Value (Hex): " + computeHash(inputText, algorithm, "hex") + "</h2>");
            out.println("<h2>Hash Value (Base64): " + computeHash(inputText, algorithm, "base64") + "</h2>");
        } else {
            out.println("<h2>Please enter some text!</h2>");
        }

        out.println("</body></html>");
    }

    public void destroy() {
    }
    private String computeHash(String inputText, String algorithm, String encoding) {
        //computes the hash of the input text by using the given methods
        try {
            //digest determines which of either hash function to use, found in previous lab
            MessageDigest digest = MessageDigest.getInstance(algorithm);
            //hashBytes is the input turned into a byte array using the respected hash algorithm
            byte[] hashBytes = digest.digest(inputText.getBytes());
            if (encoding.equals("hex")) {
                return DatatypeConverter.printHexBinary(hashBytes);
            } else if (encoding.equals("base64")) {
                return DatatypeConverter.printBase64Binary(hashBytes);
            }
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return "Error computing hash!";
    }
}