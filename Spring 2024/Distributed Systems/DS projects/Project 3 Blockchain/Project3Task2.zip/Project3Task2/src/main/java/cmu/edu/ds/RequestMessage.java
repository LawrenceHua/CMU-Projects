package cmu.edu.ds;
//lawrence hua
//lhua
//lhua@andrew.cmu.edu
import com.google.gson.Gson;

import java.math.BigInteger;

public class RequestMessage {
    private String message;
    private int numberOfBlocks; // Number of blocks in the blockchain
    private String clientID;

    public void setPublicKey(BigInteger publicKey) {
        this.publicKey = publicKey;
    }

    private BigInteger publicKey; // Public key
    private String signature; // Signature

    public BigInteger getModulus() {
        return modulus;
    }

    public void setModulus(BigInteger modulus) {
        this.modulus = modulus;
    }

    private BigInteger modulus;
    public RequestMessage(String message) {
        this.message = message;
        this.numberOfBlocks = numberOfBlocks;
    }

    // Constructor for option 1: Add a transaction to the blockchain
    public RequestMessage( BigInteger modulus ,String clientID, String userInput, String difficultyInput, String transactionInput, BigInteger publicKey, String signature) {
        this.message = clientID + " " + userInput + " " + difficultyInput + " " + transactionInput;
        this.clientID = clientID;
        this.publicKey = publicKey;
        this.signature = signature;
        this.modulus = modulus;
    }

    // Constructor for other options
    public RequestMessage(BigInteger modulus ,String userInput, String clientID, BigInteger publicKey, String signature) {
        this.message = userInput;
        this.clientID = clientID;
        this.publicKey = publicKey;
        this.signature = signature;
        this.modulus = modulus;
    }

    // Getters and setters

    public String getMessage() {
        return message;
    }

    public String getClientID() {
        return clientID;
    }

    public BigInteger getPublicKey() {
        return publicKey;
    }

    public String getSignature() {
        return signature;
    }

    // Convert object to JSON
    public String toJson() {
        Gson gson = new Gson();
        return gson.toJson(this);
    }

    // Parse JSON to object
    public static RequestMessage fromJson(String json) {
        Gson gson = new Gson();
        return gson.fromJson(json, RequestMessage.class);
    }

    public String getRSAPublicKey() {
        return publicKey.toString();

    }
}
