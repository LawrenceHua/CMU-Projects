package cmu.edu.ds;
//lawrence hua
//lhua
//lhua@andrew.cmu.edu
import java.io.*;
import java.math.BigInteger;
import java.net.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;

public class SigningClientTCP {

    private static BigInteger RSAPublicKey;
    private static BigInteger RSAPrivateKey;
    private static BigInteger RSAModulus;
    private static BigInteger clientID;

    public static void main(String args[]) {
        Socket clientSocket = null;
        Scanner scanner = new Scanner(System.in);

        try {
            int serverPort = 7777;
            clientSocket = new Socket("localhost", serverPort);

            BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            PrintWriter out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream())));


            Map<String, BigInteger> rsaKeys = createRSAPubAndPrivKeys(); // Generate RSA keys
            RSAPublicKey = rsaKeys.get("publicExponent");
            RSAPrivateKey = rsaKeys.get("privateKey");
            RSAModulus = rsaKeys.get("modulus");
            clientID = computeClientID(RSAPublicKey,RSAModulus); // Compute client ID

            System.out.println(clientID);
            System.out.println("RSA Public Key (e,n): " + RSAPublicKey + "," + RSAModulus);
            System.out.println("RSA Private Key (d,n): " + RSAPrivateKey + "," + RSAModulus);
            System.out.println("Client ID: " + clientID);
            while (true) {
                displayMenu();

                String userInput = scanner.nextLine();

                if (userInput.equals("6")) {
                    out.println(userInput);
                    out.flush();
                    break;
                }

                if (userInput.equals("1")) {
                    System.out.println("Enter difficulty > 1: ");
                    String difficultyInput = scanner.nextLine();
                    System.out.println("Enter transaction: ");
                    String transactionInput = scanner.nextLine();

                    String messageToSign = userInput + clientID;
                    String signature = sign(messageToSign);

                    RequestMessage requestMessage = new RequestMessage(RSAModulus, clientID.toString(), userInput, difficultyInput, transactionInput, RSAPublicKey, signature);

                    String jsonRequest = requestMessage.toJson();

                    out.println(jsonRequest);
                    out.flush();
                } else if (userInput.equals("4")) {
                    System.out.println("Corrupt the Blockchain");
                    System.out.println("Enter block ID of block to corrupt: ");
                    String blockID = scanner.nextLine();
                    System.out.println("Enter new data for block " + blockID + ": ");
                    String newData = scanner.nextLine();

                    String messageToSign = userInput + clientID;
                    String signature = sign(messageToSign);

                    RequestMessage requestMessage = new RequestMessage(RSAModulus, clientID.toString(), userInput, blockID, newData, RSAPublicKey, signature);

                    String jsonRequest = requestMessage.toJson();

                    out.println(jsonRequest);
                    out.flush();
                } else {
                    String messageToSign = userInput + clientID;
                    String signature = sign(messageToSign);
                    System.out.println("this is sig@@" + signature);
                    RequestMessage requestMessage = new RequestMessage(RSAModulus,userInput, clientID.toString(), RSAPublicKey, signature);

                    String jsonRequest = requestMessage.toJson();

                    out.println(jsonRequest);
                    out.flush();
                }

                String jsonResponse = in.readLine();
                System.out.println("This is the response" + jsonResponse);
                ResponseMessage responseMessage = ResponseMessage.fromJSON(jsonResponse);

                String content = responseMessage.getMessage();

                System.out.print(content);
            }
        } catch (IOException e) {
            System.out.println("IO Exception: " + e.getMessage());
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            try {
                if (clientSocket != null) {
                    clientSocket.close();
                }
            } catch (IOException e) {
                // ignore exception on close
            }
        }
    }

    private static void displayMenu() {
        System.out.println("0. View basic blockchain status.");
        System.out.println("1. Add a transaction to the blockchain.");
        System.out.println("2. Verify the blockchain.");
        System.out.println("3. View the blockchain.");
        System.out.println("4. Corrupt the chain.");
        System.out.println("5. Hide the corruption by recomputing hashes.");
        System.out.println("6. Exit.");
        System.out.println("Enter your choice: ");
    }

    private static Map<String, BigInteger> createRSAPubAndPrivKeys() {
        Random rnd = new Random();
        BigInteger p = new BigInteger(400, 100, rnd);
        BigInteger q = new BigInteger(400, 100, rnd);
        BigInteger n = p.multiply(q);
        BigInteger e = new BigInteger("65537");
        BigInteger phi = (p.subtract(BigInteger.ONE)).multiply(q.subtract(BigInteger.ONE));
        BigInteger d = e.modInverse(phi);

        Map<String, BigInteger> keys = new HashMap<>();
        keys.put("publicExponent", e);
        keys.put("modulus", n);
        keys.put("privateKey", d);
        return keys;
    }

    private static BigInteger computeClientID(BigInteger RSAPublicKey, BigInteger RSAModulus) {
        String idString = RSAPublicKey.toString() + RSAModulus.toString();
        System.out.println("id stromg" + idString);
        return computeHash(idString);
    }

    private static BigInteger computeHash(String input) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(input.getBytes());
            return new BigInteger(1, hash);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return BigInteger.ZERO;
        }
    }

    public static String sign(String message) throws Exception {

        // compute the digest with SHA-256
        byte[] bytesOfMessage = message.getBytes("UTF-8");
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] bigDigest = md.digest(bytesOfMessage);

        // we only want two bytes of the hash for ShortMessageSign
        // we add a 0 byte as the most significant byte to keep
        // the value to be signed non-negative.
        byte[] messageDigest = new byte[3];
        messageDigest[0] = 0;   // most significant set to 0
        messageDigest[1] = bigDigest[0]; // take a byte from SHA-256
        messageDigest[2] = bigDigest[1]; // take a byte from SHA-256

        // The message digest now has three bytes. Two from SHA-256
        // and one is 0.

        // From the digest, create a BigInteger
        BigInteger m = new BigInteger(messageDigest);

        // encrypt the digest with the private key
        BigInteger c = m.modPow(RSAPrivateKey,RSAModulus);

        // return this as a big integer string
        return c.toString();
    }
    private static byte[] computeSHA256Hash(String data) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            return digest.digest(data.getBytes());
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }



}
