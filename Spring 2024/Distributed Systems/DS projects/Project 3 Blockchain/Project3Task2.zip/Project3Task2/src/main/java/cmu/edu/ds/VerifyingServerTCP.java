package cmu.edu.ds;
//lawrence hua
//lhua
//lhua@andrew.cmu.edu
import com.google.gson.JsonSyntaxException;

import java.io.*;
import java.math.BigInteger;
import java.net.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

public class VerifyingServerTCP {
    // Initialize a blockchain instance
    public static BlockChain blockchain = new BlockChain();

    // StringBuilder to accumulate JSON request messages
    private static StringBuilder requestMessages = new StringBuilder();

    // StringBuilder to accumulate JSON response messages
    private static StringBuilder responseMessages = new StringBuilder();

    public static void main(String args[]) {
        ServerSocket serverSocket = null;
        Socket clientSocket = null;
        try {
            int serverPort = 7777;
            serverSocket = new ServerSocket(serverPort);

            // Server started message
            System.out.println("Blockchain server running");

            while (true) {
                // Accept incoming connections
                clientSocket = serverSocket.accept();

                // Initialize input and output streams
                BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                PrintWriter out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream())));

                // Notify that a visitor has connected
                System.out.println("We have a visitor");

                // Create the genesis block for the blockchain
                Block genesisBlock = new Block(0, blockchain.getTime(), "Genesis", 2);
                blockchain.addBlock(genesisBlock);

                String request;
                while ((request = in.readLine()) != null) {
                    try {
                        if (request.equals("6")) {
                            System.out.println("THE JSON REQUEST MESSAGES:");
                            System.out.print(requestMessages);
                            System.out.println("THE JSON RESPONSE MESSAGES:");
                            System.out.print(responseMessages);

                            // Output total number of blocks on the chain
                            System.out.println("Number of Blocks on Chain == " + blockchain.getChainSize());
                            System.out.println();
                            break;
                        }

                        // Deserialize the JSON request into a RequestMessage object
                        RequestMessage requestMessage = RequestMessage.fromJson(request);

                        // Extract client ID, public key, request, and signature from the request
                        String clientID = requestMessage.getClientID();
                        String publicKey = requestMessage.getRSAPublicKey();
                        String message = requestMessage.getMessage();
                        String signature = String.valueOf(requestMessage.getSignature());
                        BigInteger modulus = requestMessage.getModulus();
                        System.out.println(modulus);

                        // Verify if public key hashes to the provided client ID
                        if (!verifyClientID(publicKey,modulus, clientID)) {
                            out.println("Error in request: Public key does not hash to the provided ID.");
                            out.flush();
                            continue;
                        }

                        // Verify the signature of the request
                        if (!verifySignature( message, signature,publicKey,modulus)) {
                            out.println("Error in request: Signature verification failed.");
                            out.flush();
                            continue;
                        }

                        // Process the request and generate a response
                        String response = processRequest(message);


                        // Accumulate the JSON request message
                        requestMessages.append(request).append("\n");

                        // Serialize the response object to JSON
                        ResponseMessage responseMessage = new ResponseMessage(response, blockchain.getChainSize());
                        String jsonResponse = responseMessage.toJSON();

                        // Accumulate the JSON response message
                        responseMessages.append(jsonResponse).append("\n");

                        // Send the JSON response to the client
                        out.println(jsonResponse);
                        out.flush();

                    } catch (JsonSyntaxException e) {
                        // Handle JSON parsing error
                        System.out.println("Invalid JSON request: " + e.getMessage());
                        // Optionally, you can send an error response to the client
                        out.println("Invalid JSON request: " + e.getMessage());
                        out.flush();
                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("IO Exception:" + e.getMessage());
        } finally {
            try {
                // Close server socket
                if (serverSocket != null) {
                    serverSocket.close();
                }
                // Close client socket
                if (clientSocket != null) {
                    clientSocket.close();
                }
            } catch (IOException e) {
                // ignore exception on close
            }
        }
    }

    // Method to process the request and generate a response
    private static String processRequest(String request) {
        String[] parts = request.split(" ", 4);
        String clientID = parts[0];
        int choice = Integer.parseInt(parts[1]);
        StringBuilder response = new StringBuilder();
        response.append("ClientID = ").append(clientID).append("\n");
        switch (choice) {
            case 0:
                response.append(getBasicBlockchainStatus());
                break;
            case 1:
                response.append(addTransaction(parts[3], Integer.parseInt(parts[2])));
                break;
            case 2:
                response.append(verifyBlockchain());
                break;
            case 3:
                response.append(viewBlockchain());
                break;
            case 4:
                response.append(corruptChain(Integer.parseInt(parts[2]), parts[3]));
                break;
            case 5:
                response.append(repairChain());
                break;
            case 6:
                response.append("Exiting...").append("\n");
                break;
            default:
                response.append("Invalid choice").append("\n");
                break;
        }
        responseMessages.append(response);
        return response.toString();
    }

    // Method to verify if the provided public key hashes to the client ID
    private static boolean verifyClientID(String publicKey,BigInteger modulus, String clientID) {
        String pubKey = publicKey +modulus.toString();
        System.out.println("client" + clientID);
        System.out.println(pubKey);
        // Hash the public key string
        String hashedPublicKey = String.valueOf(computeHash(pubKey));
        System.out.println("hashed: " + hashedPublicKey);

        // Check if the hashed public key string matches the client ID string
        return hashedPublicKey.equals(clientID);
    }

    public static boolean verifySignature(String messageToCheck, String sig, String e, BigInteger n)throws Exception  {

        // Take the encrypted string and make it a big integer
        BigInteger encryptedHash = new BigInteger(sig);
        // Decrypt it
        BigInteger r = new BigInteger(e);
        BigInteger decryptedHash = encryptedHash.modPow(r, n);

        // Get the bytes from messageToCheck
        byte[] bytesOfMessageToCheck = messageToCheck.getBytes("UTF-8");

        // compute the digest of the message with SHA-256
        MessageDigest md = MessageDigest.getInstance("SHA-256");

        byte[] messageToCheckDigest = md.digest(bytesOfMessageToCheck);

        // messageToCheckDigest is a full SHA-256 digest
        // take two bytes from SHA-256 and add a zero byte
        byte[] extraByte = new byte[3];
        extraByte[0] = 0;
        extraByte[1] = messageToCheckDigest[0];
        extraByte[2] = messageToCheckDigest[1];

        // Make it a big int
        BigInteger bigIntegerToCheck = new BigInteger(extraByte);

        // inform the client on how the two compare
        if(bigIntegerToCheck.compareTo(decryptedHash) == 0) {

            return true;
        }
        else {
            return false;
        }
    }


    private static BigInteger computeHash(String input) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(input.getBytes());
            return new BigInteger(1, hash);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return BigInteger.ZERO;
        }
    }

    // Method to get basic blockchain status
    private static String getBasicBlockchainStatus() {
        // StringBuilder to accumulate response
        StringBuilder response = new StringBuilder();
        response.append("Current size of chain: ").append(blockchain.getChainSize()).append("\n");
        response.append("Difficulty of most recent block: ").append(blockchain.getLatestBlock().getDifficulty()).append("\n");
        response.append("Total difficulty for all blocks: ").append(blockchain.getTotalDifficulty()).append("\n");
        try {
            // Attempt to compute hashes per second
            BlockChain.computeHashesPerSecond();
            response.append("Approximate hashes per second on this machine: ").append(blockchain.getHashesPerSecond()).append("\n");
        } catch (NoSuchAlgorithmException e) {
            // If an exception occurs, include error message in the response
            response.append("Failed to compute hashes per second: ").append(e.getMessage()).append("\n");
        }
        response.append("Expected total hashes required for the whole chain: ").append(String.format("%.6f", blockchain.getTotalExpectedHashes())).append("\n");
        response.append("Nonce for most recent block: ").append(blockchain.getLatestBlock().getNonce()).append("\n");
        response.append("Chain hash: ").append(blockchain.getChainHash()).append("\n");
        return response.toString();
    }

    // Method to add a transaction to the blockchain
    private static String addTransaction(String data, int difficulty) {
        // StringBuilder to accumulate response
        StringBuilder response = new StringBuilder();
        String newData = data;
        Block newBlock = new Block(blockchain.getChainSize(), blockchain.getTime(), newData, difficulty);
        long startTime = System.currentTimeMillis();
        blockchain.addBlock(newBlock);
        long endTime = System.currentTimeMillis();
        response.append("Total execution time to add this block was ").append(endTime - startTime).append(" milliseconds.").append("\n");
        return response.toString();
    }

    // Method to verify the blockchain
    private static String verifyBlockchain() {
        // StringBuilder to accumulate response
        StringBuilder response = new StringBuilder();
        response.append("Verifying entire chain\n");
        long startTime = System.currentTimeMillis();
        String validationResult = blockchain.isChainValid();
        long endTime = System.currentTimeMillis();
        response.append("Chain verification: ").append(validationResult).append("\n");
        response.append("Total execution time required to verify the chain was ").append(endTime - startTime).append(" milliseconds").append("\n");
        return response.toString();
    }

    // Method to view the blockchain
    private static String viewBlockchain() {
        return "View the Blockchain\n" + blockchain.toString();
    }

    // Method to corrupt the blockchain
    private static String corruptChain(int blockIndex, String newData) {
        // StringBuilder to accumulate response
        StringBuilder response = new StringBuilder();
        blockchain.chain.get(blockIndex).setData(newData);
        response.append("Block ").append(blockIndex).append(" now holds ").append(newData).append("\n");
        return response.toString();
    }

    // Method to repair the blockchain
    private static String repairChain() {
        // StringBuilder to accumulate response
        StringBuilder response = new StringBuilder();
        response.append("Repairing the entire chain\n");
        long startTime = System.currentTimeMillis();
        blockchain.repairChain();
        long endTime = System.currentTimeMillis();
        response.append("Total execution time required to repair the chain was ").append(endTime - startTime).append(" milliseconds.").append("\n");
        return response.toString();
    }
    private static byte[] computeSHA256Hash(String data) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            return digest.digest(data.getBytes());
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }

}
