package cmu.edu.ds;
//lawrence hua
//lhua
//lhua@andrew.cmu.edu
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Timestamp;

public class Block {
    private int index;
    private Timestamp timestamp;
    private String data;
    private String previousHash;
    private BigInteger nonce;
    private int difficulty;
    public int hashes=0;
    public String hash;
    public Block(int index, Timestamp timestamp, String data, int difficulty) {
        this.index = index;
        this.timestamp = timestamp;
        this.data = data;
        this.previousHash = "";
        this.nonce = BigInteger.ZERO;
        this.difficulty = difficulty;
    }

    public String calculateHash() {
        String input = index + timestamp.toString() + data + previousHash + nonce.toString() + difficulty;
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(input.getBytes());
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }

    public BigInteger getNonce() {
        return nonce;
    }

    public String proofOfWork() {
        hash = calculateHash();
        while (!isValidHash(hash)) {
            hashes++;
            nonce = nonce.add(BigInteger.ONE);
            hash = calculateHash();
        }
        return hash;
    }

    private boolean isValidHash(String hash) {
        for (int i = 0; i < difficulty; i++) {
            if (hash.charAt(i) != '0') {
                return false;
            }
        }
        return true;
    }

    public Timestamp getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Timestamp timestamp) {
        this.timestamp = timestamp;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getPreviousHash() {
        return previousHash;
    }

    public void setPreviousHash(String previousHash) {
        this.previousHash = previousHash;
    }

    public int getDifficulty() {
        return difficulty;
    }

    public void setDifficulty(int difficulty) {
        this.difficulty = difficulty;
    }

    @Override
    public String toString() {
        return "{" +
                "\"index\": " + index +
                ", \"time stamp \": \"" + timestamp +
                "\", \"Tx \": \"" + data + '\'' +
                "\", \"PrevHash\": \"" + previousHash + '\'' +
                ", \"nonce\": " + nonce +
                ", \"difficulty\": " + difficulty +
                '}';
    }
}
