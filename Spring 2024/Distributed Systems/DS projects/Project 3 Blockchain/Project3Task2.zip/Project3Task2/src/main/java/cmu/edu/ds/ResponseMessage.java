package cmu.edu.ds;
//lawrence hua
//lhua
//lhua@andrew.cmu.edu
import com.google.gson.Gson;

public class ResponseMessage {
    private String message; // Message to be sent to the client
    private int numberOfBlocks; // Number of blocks in the blockchain

    // Constructor
    public ResponseMessage(String message, int numberOfBlocks) {
        this.message = message;
        this.numberOfBlocks = numberOfBlocks;
    }

    public ResponseMessage() {

    }

    // Getters and Setters
    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public int getNumberOfBlocks() {
        return numberOfBlocks;
    }

    public void setNumberOfBlocks(int numberOfBlocks) {
        this.numberOfBlocks = numberOfBlocks;
    }

    // Method to serialize the object to a JSON string
    public String toJSON() {
        Gson gson = new Gson();
        return gson.toJson(this);
    }

    // Method to deserialize a JSON string into an object
    public static ResponseMessage fromJSON(String json) {
        Gson gson = new Gson();
        return gson.fromJson(json, ResponseMessage.class);
    }

}