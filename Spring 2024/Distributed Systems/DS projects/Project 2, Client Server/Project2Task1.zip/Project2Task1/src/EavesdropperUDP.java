import java.net.*;
import java.io.*;
//Lawrence hua
//LHUA
public class EavesdropperUDP {
    public static void main(String args[]) {
        args = new String[]{"localhost"};
        DatagramSocket serverSocket = null;
        DatagramSocket clientSocket = null;
        byte[] buffer = new byte[1000];
        try {
            // Prompt user for the port to listen on and the port to masquerade as the server
            BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("Enter the port number for eavesdropping: ");
            int eavesdropPort = Integer.parseInt(reader.readLine());
            System.out.print("Enter the port number of the server Eavesdropper is masquerading as: ");
            int serverPort = Integer.parseInt(reader.readLine());

            // Start the eavesdropper on the specified port
            serverSocket = new DatagramSocket(eavesdropPort);
            System.out.println("EavesdropperUDP is running.");

            // Socket to masquerade as the server
            clientSocket = new DatagramSocket();
            // Start listening for messages
            while (true) {
                // Receive message from the client
                DatagramPacket request = new DatagramPacket(buffer, buffer.length);
                serverSocket.receive(request);
                String received = new String(request.getData(), 0, request.getLength());

                // Display the message received from the client
                System.out.println("Client: " + received);

                // If message contains "like", replace with "dislike" only once
                if (received.contains("like")) {
                    received = received.replaceFirst("like", "dislike");
                }
                InetAddress aHost = InetAddress.getByName(args[0]);

                // Send modified message to the server
                DatagramPacket responseToServer = new DatagramPacket(received.getBytes(), received.getBytes().length,aHost , serverPort);
                serverSocket.send(responseToServer);

                // Receive response from the server
                DatagramPacket serverResponse = new DatagramPacket(buffer, buffer.length);
                serverSocket.receive(serverResponse);

                // Forward server's response back to the client
                DatagramPacket responseToClient = new DatagramPacket(serverResponse.getData(), serverResponse.getLength(), request.getAddress(), request.getPort());
                clientSocket.send(responseToClient);

                //clear buffer so theres no spam
                buffer = new byte[1000];
            }
//catch exceptions and finally close sockets once everything is done.
        } catch (SocketException e) {
            System.out.println("Socket Exception: " + e.getMessage());
        } catch (IOException e) {
            System.out.println("IO Exception: " + e.getMessage());
        } finally {
            if (serverSocket != null) serverSocket.close();
            if (clientSocket != null) clientSocket.close();
        }
    }
}
