import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.*;
//Lawrence hua
//LHUA
public class RemoteVariableClientUDP {

    public static void main(String args[]) {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("The client is running.");
        System.out.println("Please enter server port: ");
        try {
            int serverPort = Integer.parseInt(reader.readLine());
            System.out.println();
            while (true) {
                System.out.println("1. Add a value to your sum.");
                System.out.println("2. Subtract a value from your sum.");
                System.out.println("3. Get your sum.");
                System.out.println("4. Exit client.");

                int option = Integer.parseInt(reader.readLine());

                if (option == 4) {
                    System.out.println("Client side quitting.");
                    break;
                }



                String operation;
                int value = 0;

                switch (option) {
                    case 1:
                        operation = "add";
                        System.out.println("Enter value to add:");
                        value = Integer.parseInt(reader.readLine());
                        break;
                    case 2:
                        operation = "subtract";
                        System.out.println("Enter value to subtract:");
                        value = Integer.parseInt(reader.readLine());
                        break;
                    case 3:
                        operation = "get";
                        break;
                    default:
                        System.out.println("Invalid option.");
                        continue;
                }
                System.out.println("Enter your ID: ");
                int id = Integer.parseInt(reader.readLine());
                String message = id + "," + operation + "," + value;
                add(serverPort, message);
            }
        } catch (IOException e) {
            System.out.println("IO Exception: " + e.getMessage());
        }
    }

    public static void add(int i, String message) {
        DatagramSocket aSocket = null;
        try {
            InetAddress aHost = InetAddress.getLocalHost();
            aSocket = new DatagramSocket();

            byte[] sendData = message.getBytes();
            DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, aHost, i);
            aSocket.send(sendPacket);

            byte[] receiveData = new byte[1024];
            DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
            aSocket.receive(receivePacket);

            String receivedMessage = new String(receivePacket.getData(), 0, receivePacket.getLength());
            System.out.println("The result is " + receivedMessage + ".\n");

        } catch (SocketException e) {
            System.out.println("Socket Exception: " + e.getMessage());
        } catch (IOException e) {
            System.out.println("IO Exception: " + e.getMessage());
        } finally {
            if (aSocket != null) {
                aSocket.close();
            }
        }
    }
}
