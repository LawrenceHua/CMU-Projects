import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.HashMap;
import java.util.Map;
//Lawrence hua
//LHUA
public class RemoteVariableServerUDP {
    public static Map<Integer, Integer> sumMap = new HashMap<>();

    public static void main(String args[]) {
        DatagramSocket aSocket = null;
        byte[] buffer = new byte[1000];
        try {
            System.out.println("The UDP server is running.");
            System.out.print("Enter server port number to listen on: ");
            BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
            int serverPort = Integer.parseInt(reader.readLine());
            aSocket = new DatagramSocket(serverPort);
            DatagramPacket request = new DatagramPacket(buffer, buffer.length);
            while (true) {
                aSocket.receive(request);
                byte[] requestData = new byte[request.getLength()];
                System.arraycopy(request.getData(), 0, requestData, 0, request.getLength());
                String[] requestDataArray = new String(requestData).split(",");
                int id = Integer.parseInt(requestDataArray[0]);
                String operation = requestDataArray[1];
                int value = 0;

                if (requestDataArray.length == 3) {
                    value = Integer.parseInt(requestDataArray[2]);
                }

                int result = 0;
                switch (operation) {
                    case "add":
                        System.out.println("Adding: " + value + " to " + get(id));
                        result = add(id, value);
                        break;
                    case "subtract":
                        System.out.println("Subtracting: " + value + " to " + get(id));
                        result = subtract(id, value);
                        break;
                    case "get":
                        System.out.println("For ID: " + id);
                        result = get(id);
                        break;
                    default:
                        System.out.println("Invalid operation.");
                }
                System.out.println("Returning sum of " + result + " to client id: "+ id);
                System.out.println();


                String response = String.valueOf(result);
                DatagramPacket reply = new DatagramPacket(response.getBytes(), response.length(),
                        request.getAddress(), request.getPort());
                aSocket.send(reply);
            }
        } catch (IOException e) {
            System.out.println("IO Exception: " + e.getMessage());
        } finally {
            if (aSocket != null) aSocket.close();
        }
    }

    public static int add(int id, int value) {
        int sum = sumMap.getOrDefault(id, 0);
        sum += value;
        sumMap.put(id, sum);
        return sum;
    }

    public static int subtract(int id, int value) {
        int sum = sumMap.getOrDefault(id, 0);
        sum -= value;
        sumMap.put(id, sum);
        return sum;
    }

    public static int get(int id) {
        return sumMap.getOrDefault(id, 0);
    }
}
