import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.*;
//Lawrence hua
//LHUA
public class AddingClientUDP {

    public static int add(int i) {
        DatagramSocket aSocket = null;
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

            System.out.println();
            // Set host name, server port for listening
            InetAddress aHost = InetAddress.getLocalHost();

            // Socket used for sending and receiving data
            aSocket = new DatagramSocket();

            while (true) {
                String input = reader.readLine();

                if (input.equals("halt!")) {
                    System.out.println("Client side quitting.");
                    break;
                }

                int num = Integer.parseInt(input);

                // Convert the number to bytes and send it to the server
                String message = String.valueOf(num);
                byte[] sendData = message.getBytes();
                //i is the serverport
                DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, aHost, i);
                aSocket.send(sendPacket);

                // Receive the result from the server
                byte[] receiveData = new byte[1024];
                DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
                aSocket.receive(receivePacket);

                // Convert the received data to an integer and print it
                String receivedMessage = new String(receivePacket.getData(), 0, receivePacket.getLength());
                System.out.println("The server returned " + receivedMessage + ".");
            }
        } catch (SocketException e) {
            System.out.println("Socket Exception: " + e.getMessage());
        } catch (IOException e) {
            System.out.println("IO Exception: " + e.getMessage());
        } finally {
            if (aSocket != null) {
                aSocket.close();
            }
        }
        return 0;
    }

    public static void main(String args[]) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("The client is running.");
        System.out.println("Please enter server port: ");
        int serverPort = Integer.parseInt(reader.readLine());
        add(serverPort);
    }
}
