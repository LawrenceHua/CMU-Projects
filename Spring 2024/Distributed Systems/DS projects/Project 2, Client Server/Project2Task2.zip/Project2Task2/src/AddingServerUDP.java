import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
//Lawrence hua
//LHUA
public class AddingServerUDP {
    public static int sum = 0;

    public static int add(int num) {
        sum += num;
        return sum;
    }

    public static void main(String args[]) {
        DatagramSocket aSocket = null;
        byte[] buffer = new byte[1000];
        try {
            System.out.println("The UDP server is running.");
            // listen/push data on port 6789
            System.out.print("Enter server port number to listen on: ");
            BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
            int serverPort = Integer.parseInt(reader.readLine()); // Pro
            aSocket = new DatagramSocket(serverPort);
            DatagramPacket request = new DatagramPacket(buffer, buffer.length);
            while (true) {
                aSocket.receive(request);
                // creates a reply after a receive and sends it
                byte[] requestData = new byte[request.getLength()];
                System.arraycopy(request.getData(), 0, requestData, 0, request.getLength());
                String requestString = new String(requestData);
                // ensure that message is received from client
                System.out.println("Adding: " + requestString + " to " + sum);
                if (requestString.equals("halt!")) {
                    System.out.println("UDP Server side quitting");
                    // Send "halt!" message back to client
                    DatagramPacket reply = new DatagramPacket(request.getData(),
                            request.getLength(), request.getAddress(), request.getPort());
                    aSocket.send(reply);
                    break; // Exit the loop
                }
                // Perform the add operation and prepare the reply
                int num = Integer.parseInt(requestString);
                int newSum = add(num);
                System.out.println("Returning sum of " + newSum + " to client");
                System.out.println();
                String replyString = String.valueOf(newSum);
                byte[] replyData = replyString.getBytes();
                DatagramPacket reply = new DatagramPacket(replyData, replyData.length,
                        request.getAddress(), request.getPort());
                aSocket.send(reply);
            }
        } catch (SocketException e) {
            System.out.println("Socket: " + e.getMessage());
        } catch (IOException e) {
            System.out.println("IO: " + e.getMessage());
        } finally {
            if (aSocket != null) aSocket.close();
        }
    }
}
