package com.ds.edu.project4lhuaweb;
//Lawrence Hua
//LHUA
import com.mongodb.*;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

import java.time.Duration;

public class ConnectToMongo {
    public static void insertData(String searchTerm, String searchIngredients, String searchRecipe, String dateTime, String systemInfo, String deviceModel, String manufacturer, String osVersion, Duration duration) {
        String connectionString = "mongodb+srv://lhua:Lwh0410Lwh0410@distributedsystemsclust.yecuro5.mongodb.net/?retryWrites=true&w=majority&appName=DistributedSystemscluster0";

        ServerApi serverApi = ServerApi.builder()
                .version(ServerApiVersion.V1)
                .build();

        MongoClientSettings settings = MongoClientSettings.builder()
                .applyConnectionString(new ConnectionString(connectionString))
                .serverApi(serverApi)
                .build();

        // Create a new client and connect to the server
        try (MongoClient mongoClient = MongoClients.create(settings)) {
            // Send a ping to confirm a successful connection
            MongoDatabase database = mongoClient.getDatabase("sample_mflix"); // Change "sample_mflix" to your database name
            database.runCommand(new Document("ping", 1));
            System.out.println("Pinged your deployment. You successfully connected to MongoDB!");

            // Write the search term, date, and system information as part of a document to the MongoDB database
            MongoCollection<Document> collection = database.getCollection("searches"); // Change "searches" to your collection name
            Document document = new Document("searchTerm", searchTerm)
                    .append("searchIngredients", searchIngredients)
                    .append("searchRecipe", searchRecipe)
                    .append("dateTime", dateTime)
                    .append("systemInfo", systemInfo)
                    .append("deviceModel", deviceModel)
                    .append("manufacturer", manufacturer)
                    .append("osVersion", osVersion)
                    .append("duration", duration.toString());
            System.out.println(duration.toString());
            collection.insertOne(document);
            System.out.println("Data inserted into MongoDB database.");
        } catch (MongoException e) {
            e.printStackTrace();
            System.out.println("fail to add into DB");
        }
    }
}
