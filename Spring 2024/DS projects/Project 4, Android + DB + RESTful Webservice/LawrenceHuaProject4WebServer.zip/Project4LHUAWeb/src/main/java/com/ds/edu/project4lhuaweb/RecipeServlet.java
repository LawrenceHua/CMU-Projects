package com.ds.edu.project4lhuaweb;
//Lawrence Hua
//LHUA

import java.io.IOException;
import java.io.PrintWriter;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.annotation.WebServlet;
import org.json.JSONObject;

@WebServlet(name = "RecipeServlet", value = "/recipe-servlet")
public class RecipeServlet extends HttpServlet {

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        response.setContentType("text/html");

        String searchTerm = request.getParameter("search");
        String deviceModel = request.getParameter("deviceModel");
        String manufacturer = request.getParameter("manufacturer");
        String osVersion = request.getParameter("osVersion");

        if(MealDBAPI.isAlpha(searchTerm)) {
            Instant start = Instant.now(); // Start time

            String mealJSON = MealDBAPI.searchMealByName(searchTerm);

            Instant end = Instant.now(); // End time
            Meal meal = MealDBAPI.parseMealFromJson(mealJSON);
            Duration duration = Duration.between(start, end);
            meal.setDuration(duration);

            List<String> ingredients = meal.getIngredients();
            String searchIngredients = null;
            if (ingredients != null) {
                // Filter out null and "null" ingredients
                List<String> nonNullIngredients = ingredients.stream()
                        .filter(ingredient -> ingredient != null && !ingredient.equals("null"))
                        .collect(Collectors.toList());

                // Join the non-null ingredients into a comma-separated string
                searchIngredients = String.join(", ", nonNullIngredients);
            }
            String searchRecipe = meal.getStrInstructions();

            // Display the meal details in the servlet response
            // Retrieve the search term from the request
            // Get current date and time
            LocalDateTime now = LocalDateTime.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            String dateTime = now.format(formatter);

            // Get system information
            String systemInfo = System.getProperty("os.name") + " " +
                    System.getProperty("os.version") + ", " +
                    System.getProperty("os.arch");

            // Create a MongoDB connection and insert search term, date, and system information
            try {
                ConnectToMongo.insertData(searchTerm, searchIngredients, searchRecipe, dateTime, systemInfo, deviceModel, manufacturer, osVersion, duration);
                // Display success message
                PrintWriter out = response.getWriter();
                out.println(mealJSON);
            } catch (Exception e) {
                e.printStackTrace();
                // Display error message
                PrintWriter out = response.getWriter();
                out.println("<html><body>");
                out.println("<h1>Error occurred: " + e.getMessage() + "</h1>");
                out.println("</body></html>");
                throw new IOException(e);
            }
        } else {
            System.out.println("No meals found");
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("message", "No meal found");
            PrintWriter out = response.getWriter();
            out.println(jsonObject);
        }

    }

    public void destroy() {
    }
}
