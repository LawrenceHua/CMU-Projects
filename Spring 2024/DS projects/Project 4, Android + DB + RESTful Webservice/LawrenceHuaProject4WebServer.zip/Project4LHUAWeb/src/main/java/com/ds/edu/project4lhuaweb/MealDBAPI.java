package com.ds.edu.project4lhuaweb;
//Lawrence hua
//LHUA
import com.google.gson.Gson;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

public class MealDBAPI {
    public static Meal parseMealFromJson(String json) {
        JSONObject jsonObject = new JSONObject(json);
        JSONArray mealsArray = jsonObject.getJSONArray("meals");
        System.out.println("json" + json);
        System.out.println("mealsArray toString" + mealsArray.toString());
        if (mealsArray.length() == 0) {
            System.out.println("no meal");
            return null; // No meal found
        }

        JSONObject mealJson = mealsArray.getJSONObject(0);

        Meal meal = new Meal();
        meal.setIdMeal(mealJson.getString("idMeal"));
        meal.setStrMeal(mealJson.getString("strMeal"));
        meal.setStrCategory(mealJson.getString("strCategory"));
        meal.setStrArea(mealJson.getString("strArea"));
        meal.setStrInstructions(mealJson.getString("strInstructions"));
        meal.setStrMealThumb(mealJson.getString("strMealThumb"));
        meal.setStrTags(mealJson.getString("strTags"));
        meal.setStrYoutube(mealJson.getString("strYoutube"));

// Extracting ingredients
        List<String> ingredients = new ArrayList<>();
        for (int i = 1; i <= 20; i++) {
            String ingredient = mealJson.optString("strIngredient" + i, null); // Use optString to handle null values
            if (ingredient != null && !ingredient.isEmpty() && !ingredient.equals("null")) {
                ingredients.add(ingredient);
            }
        }
        meal.setIngredients(ingredients);
        // Extracting measures
        List<String> measures = new ArrayList<>();
        for (int i = 1; i <= 20; i++) {
            String measure = mealJson.optString("strMeasure" + i);
            if (!measure.isEmpty() && !measure.equals("null")) {
                measures.add(measure);
            }
        }

        meal.setMeasures(measures);
        return meal;
    }
    public static boolean isAlpha(String input) throws IOException {
        for (int i = 0; i < input.length(); i++) {
            char ch = input.charAt(i);
            if (!Character.isLetter(ch) && ch != ' ' && ch != '(' && ch != ')') {
                return false;
            }
        }

        if(searchMealByName(input).equals("No meals found")){
            return false;
        }

        return true;
    }
    public static String searchMealByName(String mealName) throws IOException {
        Instant start = Instant.now(); // Start time

        try {
            URL url = new URL("https://www.themealdb.com/api/json/v1/1/search.php?s=" + mealName);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();

            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String inputLine;
            StringBuilder response = new StringBuilder();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }

            // Close the buffered reader
            in.close();
            // Check if the response contains no meals
            if (response.toString().contains("\"meals\":null")) {
                return "No meals found";
            }
            // Return the JSON response
            return response.toString();
        } catch (IOException e) {
            e.printStackTrace();
            return "No meals found";
        }
    }


}
