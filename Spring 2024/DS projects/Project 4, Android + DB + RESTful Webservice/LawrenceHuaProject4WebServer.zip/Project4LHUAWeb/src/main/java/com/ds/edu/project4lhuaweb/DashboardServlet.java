package com.ds.edu.project4lhuaweb;
//Lawrence Hua
//LHUA
import com.mongodb.client.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.annotation.WebServlet;
import org.bson.Document;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

@WebServlet(name = "dashboard", value = "/dashboard")
public class DashboardServlet extends HttpServlet {

    // Modify the DashboardServlet to include additional information
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        response.setContentType("text/html");

        // Connect to MongoDB
        try (MongoClient mongoClient = MongoClients.create("mongodb+srv://lhua:Lwh0410Lwh0410@distributedsystemsclust.yecuro5.mongodb.net/?retryWrites=true&w=majority&appName=DistributedSystemscluster0")) {
            // Accessing the database
            MongoDatabase database = mongoClient.getDatabase("sample_mflix");

            // Accessing the collection
            MongoCollection<Document> collection = database.getCollection("searches");

            // Initialize analytics variables
            Map<String, Integer> searchTermFrequency = new HashMap<>();
            Map<String, Duration> searchTermDuration = new HashMap<>();
            Map<String, Integer> deviceModelCount = new HashMap<>();

            // Retrieve documents and perform analytics
            FindIterable<Document> documents = collection.find().sort(new Document("dateTime", -1));
            for (Document doc : documents) {
                String searchTerm = doc.getString("searchTerm");
                String deviceModel = doc.getString("deviceModel");
                Duration duration = Duration.parse(doc.getString("duration"));

                // Update search term frequency
                searchTermFrequency.put(searchTerm, searchTermFrequency.getOrDefault(searchTerm, 0) + 1);

                // Update search term duration
                if (duration != null) {
                    searchTermDuration.put(searchTerm, searchTermDuration.getOrDefault(searchTerm, Duration.ZERO).plus(duration));
                }

                // Update device model count
                deviceModelCount.put(deviceModel, deviceModelCount.getOrDefault(deviceModel, 0) + 1);
            }

            // Prepare HTML response
            PrintWriter out = response.getWriter();
            out.println("<html><body>");
            out.println("<h1>Operations Analytics</h1>");

            // Display top 10 search terms in a table
            out.println("<h2>Top 10 Search Terms</h2>");
            out.println("<table border=\"1\">");
            out.println("<tr><th>Search Term</th><th>Frequency</th></tr>");
            searchTermFrequency.entrySet().stream()
                    .sorted((entry1, entry2) -> entry2.getValue().compareTo(entry1.getValue())) // Sort by frequency
                    .limit(10) // Limit to top 10
                    .forEach(entry -> {
                        out.println("<tr>");
                        out.println("<td>" + entry.getKey() + "</td>");
                        out.println("<td>" + entry.getValue() + "</td>");
                        out.println("</tr>");
                    });
            out.println("</table>");

            // Calculate average duration for each search term
            out.println("<h2>Average Duration for Each Search Term</h2>");
            out.println("<table border=\"1\">");
            out.println("<tr><th>Search Term</th><th>Average Duration (milliseconds)</th></tr>");
            searchTermDuration.entrySet().forEach(entry -> {
                long averageSeconds = entry.getValue().toMillis() / searchTermFrequency.get(entry.getKey());
                out.println("<tr>");
                out.println("<td>" + entry.getKey() + "</td>");
                out.println("<td>" + averageSeconds + "</td>");
                out.println("</tr>");
            });
            out.println("</table>");

            // Display top 5 Android phone models making requests
            out.println("<h2>Top 5 Android Phone Models Making Requests</h2>");
            out.println("<table border=\"1\">");
            out.println("<tr><th>Device Model</th><th>Number of Requests</th></tr>");
            deviceModelCount.entrySet().stream()
                    .sorted((entry1, entry2) -> entry2.getValue().compareTo(entry1.getValue())) // Sort by count
                    .limit(5) // Limit to top 5
                    .forEach(entry -> {
                        out.println("<tr>");
                        out.println("<td>" + entry.getKey() + "</td>");
                        out.println("<td>" + entry.getValue() + "</td>");
                        out.println("</tr>");
                    });
            out.println("</table>");

            // Display data from MongoDB
            out.println("<h1>Logs</h1>");
            out.println("<table border=\"1\">");
            out.println("<tr><th>Search Term</th><th>Search Ingredients</th><th>Search Recipe</th><th>Date/Time</th><th>System Info</th><th>Device Model</th><th>Manufacturer</th><th>OS Version</th></tr>");

            // Retrieve documents and display them in HTML table format
            for (Document doc : documents) {
                String searchTerm = doc.getString("searchTerm");
                String searchIngredients = doc.getString("searchIngredients");
                String searchRecipe = doc.getString("searchRecipe");
                String dateTime = doc.getString("dateTime");
                String systemInfo = doc.getString("systemInfo");
                String deviceModel = doc.getString("deviceModel");
                String manufacturer = doc.getString("manufacturer");
                String osVersion = doc.getString("osVersion");

                // Display document in HTML table format
                out.println("<tr>");
                out.println("<td>" + searchTerm + "</td>");
                out.println("<td>" + searchIngredients + "</td>");
                out.println("<td>" + searchRecipe + "</td>");
                out.println("<td>" + dateTime + "</td>");
                out.println("<td>" + systemInfo + "</td>");
                out.println("<td>" + deviceModel + "</td>");
                out.println("<td>" + manufacturer + "</td>");
                out.println("<td>" + osVersion + "</td>");
                out.println("</tr>");
            }

            out.println("</table>");
            out.println("</body></html>");
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Error: " + e.getMessage());
        }
    }

    public void destroy() {
    }
}
