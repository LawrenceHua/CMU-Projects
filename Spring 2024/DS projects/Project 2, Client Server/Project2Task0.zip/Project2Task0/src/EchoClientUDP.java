import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
//Lawrence hua
//LHUA
public class EchoClientUDP {
    public static void main(String args[]) {
        args = new String[]{"localhost"};
        // args give message contents and server hostname
        DatagramSocket aSocket = null;
        try {
            // set host name, server port for listening,
            InetAddress aHost = InetAddress.getByName(args[0]);

            // socket used for sending and receiving data.
            aSocket = new DatagramSocket();
            String nextLine;
            System.out.println("The UDP client is running.");
            System.out.print("Enter server port number: ");
            // allows user to type text into console
            BufferedReader typed = new BufferedReader(new InputStreamReader(System.in));
            int serverPort = Integer.parseInt(typed.readLine());
            while ((nextLine = typed.readLine()) != null) {
                if (nextLine.equals("halt!")) {
                    // Send "halt!" message to server
                    byte[] m = nextLine.getBytes();
                    DatagramPacket request = new DatagramPacket(m, m.length, aHost, serverPort);
                    aSocket.send(request);
                    System.out.println("UDP Client side quitting");
                    break; // Exit the loop
                }
                byte[] m = nextLine.getBytes();
                // sends message containing message, length, destination address, and destination port.
                DatagramPacket request = new DatagramPacket(m, m.length, aHost, serverPort);
                aSocket.send(request);
                byte[] buffer = new byte[1000];
                // get data from server
                DatagramPacket reply = new DatagramPacket(buffer, buffer.length);
                aSocket.receive(reply);
                byte[] replyData = new byte[reply.getLength()];
                System.arraycopy(reply.getData(), 0, replyData, 0, reply.getLength());
                System.out.println("Reply from server: " + new String(replyData));
            }
        } catch (SocketException e) {
            System.out.println("Socket Exception: " + e.getMessage());
        } catch (IOException e) {
            System.out.println("IO Exception: " + e.getMessage());
        } finally {
            if (aSocket != null) aSocket.close();
        }
    }
}
